<?php
/*
 * Bạn có thể tự viết thêm Constants vào đây (có thể sẽ bị ghi đè bởi Constants gốc)
 */

// Routes mặc định của bản code gốc, chỉ xóa bỏ khi thực sự cần thiết
include __DIR__ . '/CustomConstants.php';

/*
 * Bạn có thể tự viết thêm Constants vào đây (ghi đè Constants gốc)
 */