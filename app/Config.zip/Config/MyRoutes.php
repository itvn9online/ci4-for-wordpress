<?php
/*
 * Bạn có thể tự viết thêm Routes vào đây (có thể sẽ bị ghi đè bởi Routes gốc)
 */

// Routes mặc định của bản code gốc, chỉ xóa bỏ khi thực sự cần thiết
include __DIR__ . '/CustomRoutes.php';

/*
 * Bạn có thể tự viết thêm Routes vào đây (ghi đè Routes gốc)
 */