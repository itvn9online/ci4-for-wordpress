<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'reference' => NULL,
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'reference' => NULL,
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'zaloplatform/zalo-php-sdk' => array(
            'pretty_version' => '4.0.3',
            'version' => '4.0.3.0',
            'reference' => '87b30627b578e25d0c4c9661a9ef600045bff640',
            'type' => 'project',
            'install_path' => __DIR__ . '/../zaloplatform/zalo-php-sdk',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
