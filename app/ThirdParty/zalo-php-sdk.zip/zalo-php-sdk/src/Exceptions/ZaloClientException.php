<?php
/**
 * Zalo © 2019
 *
 */

namespace Zalo\Exceptions;

use Zalo\Exceptions\ZaloSDKException;

/**
 * Class ZaloClientException
 *
 * @package Zalo
 */
class ZaloClientException extends ZaloSDKException
{
}
