<?php

echo $main;