<div id="breadcrumb-top1">
    <div class="thread-details-tohome">
        <div class="w90">
            <ul class="cf">
                <li><a href="./"><i class="fa fa-home"></i> Trang chủ</a></li>
                <?php
                echo implode( ' ', $breadcrumb );
                ?>
            </ul>
        </div>
    </div>
</div>
