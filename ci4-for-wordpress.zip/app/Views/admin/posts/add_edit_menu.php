<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

<link rel="stylesheet" href="./admin/Drag-Drop-Menu-Builder-For-Bootstrap/bootstrap-iconpicker/css/bootstrap-iconpicker.min.css" />
<script src="./admin/Drag-Drop-Menu-Builder-For-Bootstrap/bootstrap-iconpicker/js/iconset/fontawesome5-3-1.min.js"></script> 
<script src="./admin/Drag-Drop-Menu-Builder-For-Bootstrap/bootstrap-iconpicker/js/bootstrap-iconpicker.min.js"></script> 
<script src="./admin/Drag-Drop-Menu-Builder-For-Bootstrap/jquery-menu-editor.js"></script>
<div class="w99 cf">
    <div class="lf f50">
        <ul id="myEditor" class="sortableLists list-group">
            <li class="list-group-item pr-0" style="width: auto; position: relative; top: 0px; left: 0px;">
                <div style="overflow: auto;"><i class="fas fa-home"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Home</span>
                    <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#" style="display: none;"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                </div>
            </li>
            <li class="list-group-item pr-0">
                <div style="overflow: auto;"><i class="fas fa-chart-bar"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Opcion2</span>
                    <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                </div>
            </li>
            <li class="list-group-item pr-0">
                <div style="overflow: auto;"><i class="fas fa-bell"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Opcion3</span>
                    <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                </div>
            </li>
            <li class="list-group-item pr-0">
                <div style="overflow: auto;"><i class="fas fa-crop"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Opcion4</span>
                    <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                </div>
            </li>
            <li class="list-group-item pr-0">
                <div style="overflow: auto;"><i class="fas fa-flask"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Opcion5</span>
                    <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                </div>
            </li>
            <li class="list-group-item pr-0">
                <div style="overflow: auto;"><i class="fas fa-map-marker"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Opcion6</span>
                    <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                </div>
            </li>
            <li class="list-group-item pr-0 sortableListsClosed">
                <div style="overflow: auto;"><span class="sortableListsOpener btn btn-success btn-sm" style="margin-right: 10px; float: none;"><i class="fas fa-plus"></i></span><i class="fas fa-search"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Opcion7</span>
                    <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#" style="display: none;"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                </div>
                <ul class="pl-0" style="padding-top: 10px; display: none;">
                    <li class="list-group-item pr-0 sortableListsClosed">
                        <div style="overflow: auto;"><span class="sortableListsOpener btn btn-success btn-sm" style="margin-right: 10px; float: none;"><i class="fas fa-plus"></i></span><i class="fas fa-plug"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Opcion7-1</span>
                            <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#" style="display: none;"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#" style="display: none;"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                        </div>
                        <ul class="pl-0" style="padding-top: 10px; display: none;">
                            <li class="list-group-item pr-0">
                                <div style="overflow: auto;"><i class="fas fa-filter"></i>&nbsp;<span class="txt" style="margin-right: 5px;">Opcion7-1-1</span>
                                    <div class="btn-group float-right"><a class="btn btn-secondary btn-sm btnUp btnMove clickable" href="#" style="display: none;"><i class="fas fa-angle-up clickable"></i></a><a class="btn btn-secondary btn-sm btnDown btnMove clickable" href="#" style="display: none;"><i class="fas fa-angle-down clickable"></i></a><a class="btn btn-secondary btn-sm btnIn btnMove clickable" href="#" style="display: none;"><i class="fas fa-level-up-alt clickable"></i></a><a class="btn btn-secondary btn-sm btnOut btnMove clickable" href="#"><i class="fas fa-level-down-alt clickable"></i></a><a class="btn btn-primary btn-sm btnEdit clickable" href="#"><i class="fas fa-edit clickable"></i></a><a class="btn btn-danger btn-sm btnRemove clickable" href="#"><i class="fas fa-trash-alt clickable"></i></a></div>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    <div class="lf f50">
        <div class="lf f50"></div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-body"> </div>
            </div>
            <p>Click the Output button to execute the function <code>getString();</code></p>
            <div class="card">
                <div class="card-header">JSON Output
                    <div class="float-right">
                        <button id="btnOutput" type="button" class="btn btn-success"><i class="fas fa-check-square"></i> Output</button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <textarea id="out" class="form-control" cols="50" rows="10"></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card border-primary mb-3">
                <div class="card-header bg-primary text-white">Edit item</div>
                <div class="card-body">
                    <form id="frmEdit" class="form-horizontal">
                        <div class="form-group">
                            <label for="text">Text</label>
                            <div class="input-group">
                                <input type="text" class="form-control item-menu" name="text" id="text" placeholder="Text">
                                <div class="input-group-append">
                                    <button type="button" id="myEditor_icon" class="btn btn-outline-secondary iconpicker dropdown-toggle">
                                    <i class="empty"></i>
                                    <input type="hidden" value="empty">
                                    <span class="caret"></span>
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" name="icon" class="item-menu">
                        </div>
                        <div class="form-group">
                            <label for="href">URL</label>
                            <input type="text" class="form-control item-menu" id="href" name="href" placeholder="URL">
                        </div>
                        <div class="form-group">
                            <label for="target">Target</label>
                            <select name="target" id="target" class="form-control item-menu">
                                <option value="_self">Self</option>
                                <option value="_blank">Blank</option>
                                <option value="_top">Top</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="title">Tooltip</label>
                            <input type="text" name="title" class="form-control item-menu" id="title" placeholder="Tooltip">
                        </div>
                    </form>
                </div>
                <div class="card-footer">
                    <button type="button" id="btnUpdate" class="btn btn-primary" disabled="disabled"><i class="fas fa-sync-alt"></i> Update</button>
                    <button type="button" id="btnAdd" class="btn btn-success"><i class="fas fa-plus"></i> Add</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php

$this->base_model->add_js( 'admin/js/add_edit_menu.js' );
