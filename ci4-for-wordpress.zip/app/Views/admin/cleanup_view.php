<ul class="admin-breadcrumb">
    <li>Dọn dẹp website</li>
</ul>
<h3>Chức năng này sẽ dọn dẹp các file cache trong thư mục:</h3>
<p><?php echo WRITEPATH . 'cache/'; ?></p>
<div>
    <form action="" method="post" name="frm_global_submit" role="form" enctype="multipart/form-data" target="target_eb_iframe">
        <input type="hidden" name="data" value="1" />
        <br>
        <div>
            <button type="submit" class="btn btn-success"><i class="fa fa-magic"></i> Bắt đầu dọn dẹp</button>
        </div>
    </form>
</div>
<br>
<br>
<br>
