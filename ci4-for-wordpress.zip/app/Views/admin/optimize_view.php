<ul class="admin-breadcrumb">
    <li>Optimize code</li>
</ul>
<?php

//
echo basename( __FILE__ ) . '<br>' . "\n";
