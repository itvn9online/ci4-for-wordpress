<?php

//
echo basename( __FILE__ ) . '<br>' . "\n";