# Views mặc định

Làm sẵn các view mặc định để ngay khi cài đặt code là website có thể hoạt động được luôn. Trong mỗi theme, nếu người dùng có nhu cầu làm view riêng thì copy file trong view default, cho vào views trong theme và tùy chỉnh lại.
