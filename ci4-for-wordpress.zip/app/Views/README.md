### view default
Các view có thêm đuôi default ở sau là các view sẽ được sử dụng khi trong theme không có view tương ứng.