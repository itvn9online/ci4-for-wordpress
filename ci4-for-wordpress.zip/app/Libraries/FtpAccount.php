<?php

namespace App\ Libraries;

class FtpAccount {
    //
}