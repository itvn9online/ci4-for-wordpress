### Đây là nơi chứa các view riêng của từng theme
Để tận dụng lại được lượng code dùng chung (có thể làm nhiều website mà tốn ít sức code nhất có thể), mỗi website sẽ được cho vào một thự mục riêng và đặt tại `themes`. Trong file config.php hãy khai báo thư mục theme để các file được nạp khi web chạy.

### Có thể kích hoạt cứng 1 theme bằng cách đặt tên theme theo dạng [thư mục chứa theme].theme
