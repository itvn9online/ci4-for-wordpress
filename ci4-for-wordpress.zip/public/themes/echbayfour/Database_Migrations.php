<?php

/*
 * bảng liệt kê các cột sẽ được bổ sung cho CSDL (với các website cần bổ sung thêm cột để select dữ liệu)
 */
$arr_custom_alter_database = [
    //WGR_TABLE_PREFIX . 'users' => [],
];