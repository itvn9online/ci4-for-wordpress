<?php
die( 'no money no love' );


/*
 * File dùng để ghi chú riêng cho mỗi theme
 */