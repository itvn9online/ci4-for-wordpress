### Đây là nơi chứa các file mẫu JS riêng của từng theme

- Lúc cần sử dụng file nào thì hãy cut file đó ra thư mục bên ngoài `../`, file sẽ được nạp mặc định theo `post_type` hoặc `taxonomy` tương ứng.