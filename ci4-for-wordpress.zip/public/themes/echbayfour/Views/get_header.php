<?php
/*
 * file header riêng của từng theme
 * giả lập tương tự như hàm get_header() của wordpress
 * nếu có file này trong theme -> nó sẽ được nạp vào cuối </head>
 */