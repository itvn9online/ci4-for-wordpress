jQuery(document).ready(function () {
    // thêm iframe để submit form cho tiện
    _global_js_eb.add_primari_iframe();
    _global_js_eb.wgr_nonce('profile_form');
    _global_js_eb.wgr_nonce('pasword_form');
});
