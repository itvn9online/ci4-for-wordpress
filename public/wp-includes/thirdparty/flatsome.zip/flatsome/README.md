# Flatsome 3.17.2:

## Code trong này copy bên flatsome sang, chủ yếu lấy thư viện javascript mà họ đã viết để tận dụng cho đỡ phải code nhiều
